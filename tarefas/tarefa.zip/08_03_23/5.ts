{
    let valor1:number = 12;
    let valor2:number = 43;

    let obj1 = {valor1, valor2}

    let obj2 = {valor1, valor2}

    console.log(obj1, obj2)
}