{
    const caminhao = {
        cor: "azul",
        numeroDeRodas: 3
    }

    let cor = caminhao.cor
    let numeroDeRodas = caminhao.numeroDeRodas

    console.log(`${cor} e ${numeroDeRodas}`)
}